---
title: Burp Suite Pro Loader&Keygen By surferxyz 1.7.32
date: 2018-02-06 00:27:32
tags:
	- tools
categories:
	- tools
	 
---


![](https://ws1.sinaimg.cn/large/006Y6f53gy1fo62jdz5zdj30n50c1wfz.jpg)
<!--more-->


### 前言

看到小伙伴都会用了，本不想写，无奈`1.7.32`又出来了，写一下吧。



`surferxy`z发布在`EXETOOLS`，地址：`https://forum.exetools.com/showpost.php?p=112008&postcount=83`，原文如下（内容转自吾爱破解）#

  
> made a loader/keygen that should work on future versions of burp suite pro, unless they specifically target it/change the license scheme.

>Download loader/keygen here: http://www36.zippyshare.com/v/WRy3bGWf/file.html

>Works on 1.6.x up until the latest version 1.7.31 and maybe into the future ;-)

>My approach is a bit different than larry_lau, and my jar is not obfuscated so you can easily verify that it is safe :-)

>You still probably need to firewall off the program like Sakaroz said, if it really does do license callbacks. (I didnt look)





`surferxyz`提供的`Loader&Keygen`程序没有混淆，可以完整看到`burp`的注册算法，并且`loader`的思路相当赞，注册机 通杀`1.6.x`到最新的`1.7.32`版 ，以后你有新版本也可以直接使用这个注册机#
程序使用很简单，可以直接打开`burp-loader-keygen.jar`即可，如果不行可以使用命令行启动：
    `java -Xbootclasspath/p:burp-loader-keygen.jar -jar burpsuite_pro_v1.7.31.jar`




`Burp Suite Pro Loader&Keygen By surferxyz 1.7.31`下载链接：

>[https://down.52pojie.cn/Tools/Network_Analyzer/Burp_Suite_Pro_v1.7.32_Loader_Keygen.zip](https://down.52pojie.cn/Tools/Network_Analyzer/Burp_Suite_Pro_v1.7.32_Loader_Keygen.zip)




### 步骤

#### 0x01

打开`burp-loader-keygen.jar`,然后点击运行`run`。

![](https://ws1.sinaimg.cn/large/006Y6f53gy1fo62pcxbz9j30mo0crq3p.jpg)

#### 0x02

把`burp-loader-keygen License`里面的`key`复制到`burp`里面，然后`next`。

![](https://ws1.sinaimg.cn/large/006Y6f53gy1fo62ry5lstj311f0jnq4a.jpg)

#### 0x03

复制`burp`里的`request`那部分数据复制到`burp-loader-keygen`的`Activation Resqust`里面，然后程序会自动在`Activation Response`生成一个序列号，把生成出来的序列号复制到`burp`里的`response`里，然后`next`。


![](https://ws1.sinaimg.cn/large/006Y6f53gy1fo62xlbs0ij31h70mo41d.jpg)




![](https://ws1.sinaimg.cn/large/006Y6f53gy1fo62yiwephj30zk0k83zo.jpg)




