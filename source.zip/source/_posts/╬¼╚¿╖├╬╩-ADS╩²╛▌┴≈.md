---
title: 维权访问-ADS数据流
date: 2018-01-21 20:55:17
tags:
	- php
categories:
	- php

---
![](https://ws1.sinaimg.cn/large/006Y6f53ly1fnrerkmrigj311y0kgq5q.jpg)

<!--more-->

受`demon`指点

学会了用`ADS`数据流维持访问

### PHP
#### 未寄宿 可以执行

 ![](https://ws1.sinaimg.cn/large/006Y6f53gy1fnojcfhfulj30gv01bdfl.jpg)

#### 寄宿数据流
![](https://ws1.sinaimg.cn/large/006Y6f53gy1fnok4fs0tlj30lt010dfl.jpg)

#### 删除文件
![](https://ws1.sinaimg.cn/large/006Y6f53gy1fnok7i6s5nj30jm06mmx8.jpg)

#### 寄宿数据流成功，并可以运行
![](https://ws1.sinaimg.cn/large/006Y6f53gy1fnokmn1qc9j30h5013a9t.jpg)

![](https://ws1.sinaimg.cn/large/006Y6f53gy1fnqwmskq8bj30k702d745.jpg)

![](https://ws1.sinaimg.cn/large/006Y6f53ly1fnrerkmrigj311y0kgq5q.jpg)

参考：[http://www.ggsec.cn/APT.html](http://www.ggsec.cn/APT.html)


### **总结:**

- 细节决定成败
