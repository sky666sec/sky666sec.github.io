---
title: python学习之变量
date: 2018-01-30 21:05:07
tags:
	- python
categories:
	- python

---


![](https://ws1.sinaimg.cn/large/006Y6f53gy1fo3b8r4r4wj30rf0l5wib.jpg)

<!--more-->

#### 变量简述

变量就是存储计算机程序中数据的容器。

有了变量，程序中的赋值操作将变得不那么繁琐，而且更加方便。
不仅仅是赋值操作，变量可以用在所有需要动态变化的参数中。
我个人理解就是变量是动态变化的量，可以用来存储数据。


    #/usr/bin/env python
    num = 12
    print(num+1)

查看变量类型可以用`type`函数

    num = 18
    str = "hello python"
    print(type(num))
    print(type(str))




#### 变量的类型

`python`是动态类型语言，定义变量的时候可以不需要指定变量类型，可以根据后面的数据推断出类型，这虽然变得方便了，但是存在不安全的因素，`php`也是，都属于弱类型语言。

`c`,`c++`,`c#`，`java`都属于静态类型语言，定义变量的时候需要指定变量类型，没法根据后面的数据推断出类型，这种相对动态类型语言来说是比较安全的。属于强类型语言。


`Numbers` (数字)

-     `int`  （有符号整形）
-    `long `长整形 （`python3`已不使用）
-   ` float` (浮点数)
-    c`omplex`(复数)

布尔类型

-    `True` (真)
-   `False` (假)
    
`String `(字符串)

`List `(列表)

`Tuple` (元组)

`Dictionary `(字典)


干什么事都需要用合适的变量类型，例如修三峡大坝就应该用下图中的那辆大的、高的车辆，而用那辆小的`SUV`就明显不合适了，而如果是在普通公路上驾驶及行驶，那这辆`SUV`就再适合不过了。

![](https://ws1.sinaimg.cn/large/006Y6f53gy1fo3b8r4r4wj30rf0l5wib.jpg)



**总结：**

- 了解了python变量的基本概念



