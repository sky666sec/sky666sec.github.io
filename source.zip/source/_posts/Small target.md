---
title: small target
date: 2018-02-17 09:48:33
tags: notes
categories: notes

---

小目标


<!--more-->


1. python 1000个练习题（每天1-2个）          (1h)    &nbsp;      ->  &nbsp; 一个可以完全运行的demo



2. 学会安装 linux(ubuntu centos kali ...)    (2h)     &nbsp;     -> &nbsp; 产出物(md 安装文档)


3. 安装Linux相关服务(至少10个)并且实现源码自动化安装(1h) &nbsp;  ->  &nbsp;shell script


4. 代码规范                                  (10min)  &nbsp;     -> &nbsp; 阅读Google文档


5. 下载金山打字通，每天练习英文打字速度      (10min)   &nbsp;    ->  &nbsp;200/min  99%
