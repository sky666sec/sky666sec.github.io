---
title: MarkdownPad2常用快捷键
date: 2018-02-17 09:47:48
tags: notes
categories: notes 

---

MarkdownPad2常用快捷键

<!--more-->

`Ctrl + I` ： 斜体

`Ctrl + B` ： 粗体

`Ctrl + G` ： 图片

`Ctrl + Q `： 引用
`
Ctrl + 1` ： 标题 1

`Ctrl + 2` ： 标题 2
`
Ctrl + 3` ： 标题 3

`Ctrl + K` ： 代码块

`Ctrl + L `： 超链接

`Ctrl + T` ： 时间戳

`Ctrl + U` ： 无序列表

`Ctrl + R` ： 水平标尺

`F4` ： 启用水平布局

`F5` ： 启用实时预览

`F6` ： 在浏览器中预览


`Ctrl + Shift + O` ： 有序列表



